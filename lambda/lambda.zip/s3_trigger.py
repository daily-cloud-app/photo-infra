"""
S3 イベントトリガー:
1. ファイルが PUT されたら DynamoDB にメタデータを自動登録
2. サムネイル画像（200px）を生成して thumbnails/ に保存
"""
import io
import os
import urllib.parse
from datetime import datetime, timezone

import boto3
from PIL import Image

PHOTOS_TABLE = os.environ.get('PHOTOS_TABLE', '')
THUMBNAIL_SIZE = (200, 200)

dynamodb = boto3.resource('dynamodb')
s3_client = boto3.client('s3')


def handler(event, context):
    table = dynamodb.Table(PHOTOS_TABLE)

    for record in event.get('Records', []):
        bucket = record['s3']['bucket']['name']
        key = urllib.parse.unquote_plus(record['s3']['object']['key'])
        size = record['s3']['object'].get('size', 0)

        # thumbnails/ プレフィックスのファイルは無視（無限ループ防止）
        if key.startswith('thumbnails/'):
            continue

        # パスから userId を抽出
        # 期待するパス: users/{userId}/2026/04/26/{photoId} or users/{userId}/{photoId}
        parts = key.split('/')
        if len(parts) < 3 or parts[0] != 'users':
            continue

        user_id = parts[1]
        # photoId はパスの最後の部分
        photo_id = parts[-1]

        # 拡張子からコンテンツタイプを推定
        ext = photo_id.rsplit('.', 1)[-1].lower() if '.' in photo_id else ''
        content_type_map = {
            'jpg': 'image/jpeg',
            'jpeg': 'image/jpeg',
            'png': 'image/png',
            'gif': 'image/gif',
            'webp': 'image/webp',
            'heic': 'image/heic',
            'heif': 'image/heic',
        }
        content_type = content_type_map.get(ext, 'application/octet-stream')

        # サムネイル生成
        thumbnail_key = f"thumbnails/{key.removeprefix('users/')}"
        try:
            _generate_thumbnail(bucket, key, thumbnail_key)
            print(f'Thumbnail generated: {thumbnail_key}')
        except Exception as e:
            print(f'Thumbnail generation failed for {key}: {e}')
            thumbnail_key = None

        # DynamoDB にメタデータを登録（既にあれば thumbnailKey を更新）
        existing = table.get_item(Key={'userId': user_id, 'photoId': photo_id})
        if 'Item' in existing:
            # 既存レコードがあれば thumbnailKey だけ更新
            if thumbnail_key:
                table.update_item(
                    Key={'userId': user_id, 'photoId': photo_id},
                    UpdateExpression='SET thumbnailKey = :tk',
                    ExpressionAttributeValues={':tk': thumbnail_key},
                )
        else:
            # 新規登録（S3 に直接入れた場合）
            item = {
                'userId': user_id,
                'photoId': photo_id,
                'filename': photo_id,
                'contentType': content_type,
                's3Key': key,
                'size': size,
                'status': 'uploaded',
                'createdAt': datetime.now(timezone.utc).isoformat(),
                'labels': [],
            }
            if thumbnail_key:
                item['thumbnailKey'] = thumbnail_key
            table.put_item(Item=item)

        print(f'Processed: {key} for user {user_id}')


def _generate_thumbnail(bucket, source_key, thumbnail_key):
    """S3 から画像を取得してサムネイルを生成し、S3 に保存"""
    # 元画像をダウンロード
    response = s3_client.get_object(Bucket=bucket, Key=source_key)
    image_data = response['Body'].read()

    # Pillow でリサイズ
    img = Image.open(io.BytesIO(image_data))
    img.thumbnail(THUMBNAIL_SIZE, Image.LANCZOS)

    # JPEG に変換して保存
    buffer = io.BytesIO()
    # RGBA の場合は RGB に変換
    if img.mode in ('RGBA', 'P'):
        img = img.convert('RGB')
    img.save(buffer, format='JPEG', quality=80)
    buffer.seek(0)

    # S3 にアップロード
    s3_client.put_object(
        Bucket=bucket,
        Key=thumbnail_key,
        Body=buffer.getvalue(),
        ContentType='image/jpeg',
    )
